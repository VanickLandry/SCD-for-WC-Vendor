﻿=== SCD - Smart Currency Detector - Premium Variant for WcVendor  ===

Contributors: gajelabs
Tags: woocommerce, plugin, currency, auto detect, converter, conversion, convert, price, foreign currencies, detector, currency detector, all-in-one.
Requires at least: 4.0.0
Tested up to: 6.0.2
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== DESCRIPTION == 

ALL-IN-ONE solution for buyers, sellers, single/multi vendors sites, market places. Best currency plugin for WC Vendor Marketplace for currency conversion

= This plugin is compatible to: =

[WcVendor (WC Vendor - Marketplace )](https://fr.wordpress.org/plugins/wc-vendors/)

== QUICK SUPPORT ==

On any days, we provide 12 hours turnaround time to reply every query, even in our busiest schedule. All you need to do is to reach us either via our support forum or [https://wordpress.org/support/plugin/scd-smart-currency-detector/](https://wordpress.org/support/plugin/scd-smart-currency-detector/)


== FEATURES ==

- The vendor can define the currency with which to create his products. In his dashboard, the products will be visible in the currency he has defined

= Minimum Requirements =

* WordPress 4.7 or greater
* WooCommerce 3.0 or greater
* PHP version 5.2.4 or greater
* MySQL version 5.0 or greater
* SCD - Smart Currency Detector - Free variant version 4.7.10

== FEEDBACK ==

We are regressed on providing you the best experience ever.

Please help us thereby telling us what we can do better, or giving an high five if we did something you love ??

We are really proud to serve and enhance WooCommerce, extending herewith the related community.


== Installation ==
	*Download to your plugin directory or simply install via WordPress admin interface.

	*Activate.

== Screenshots ==

1. WC-Vendors Vendor Dashboard SCD Menu
2. WC-Vendors SCD Currency Content
3. WC-Vendors List Of Currencies 
4. WC-Vendors Home Dashboard
5. WC-Vendors Products Dashboard
6. WC-Vendors Add Simple Product

== SUPPORT ==

If you have any problems.

[SCD FAQ](https://gajelabs.com/frequently-asked-questions/)

== CHANGELOG ==
= 4.1.0 =
* Allows the vendor to choose the currency to use in his shop